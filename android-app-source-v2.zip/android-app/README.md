# مالي للجوال — Android

تطبيق Android خفيف يفتح نسخة مالي المنشورة داخل WebView آمن، مع دعم RTL وصفحة انقطاع اتصال محلية.

يبني GitHub Actions ملف `Mali-Android.apk` موقّعًا بمفتاح Android التجريبي، ثم ينشره تلقائيًا في GitHub Releases تحت الوسم `android-v1.0.0`.

رابط التنزيل المتوقع:

`https://github.com/ha7n-bot/personal-finance-app/releases/download/android-v1.0.0/Mali-Android.apk`
